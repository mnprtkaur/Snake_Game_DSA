# SNAKE GAME USING DATA STRUCTURES AND ALGORITHMS
## Project Report

### 1. Introduction
Snake Game is a classic grid-based game in which the player controls a snake that moves around the board and eats food. Each time food is eaten, the snake grows and the score increases. The game ends when the snake hits the boundary or its own body.

This project implements the game in C++ with the SFML graphics library. Its main academic focus is the use of a manually implemented doubly linked list to represent the snake.

### 2. Objectives
- Apply linked-list concepts in a working application.
- Implement insertion and deletion operations.
- Use coordinate-based movement and collision detection.
- Apply random number generation for food placement.
- Store and rank player scores using file handling and sorting.
- Develop a modular C++ application.

### 3. Tools and Technologies
- Language: C++17
- Graphics: SFML 3
- Build system: CMake
- Concepts: Doubly linked list, searching, sorting, randomization, file handling

### 4. Data Structures Used
**Doubly linked list:** Each snake segment is a node containing an (x, y) coordinate, a pointer to the next node, and a pointer to the previous node. The head is where new segments are inserted. The tail is where the last segment is removed during normal movement.

**Vector:** The leaderboard uses a vector to store player names and scores.

**File:** The leaderboard is saved in a text file so scores can remain available after the program closes.

### 5. Algorithms
**Movement algorithm**
1. Copy the current head coordinate.
2. Update the coordinate according to the current direction.
3. Check whether the new coordinate is outside the board.
4. Check whether the new coordinate collides with the snake body.
5. Insert a new node at the head.
6. If food was not eaten, delete the tail; otherwise keep the tail and place new food.

**Food generation algorithm**
1. Generate a random column and row.
2. Check whether the coordinate is already occupied by the snake.
3. Repeat until an unoccupied coordinate is found.

**Leaderboard algorithm**
1. Read saved name-score pairs from a text file.
2. Add a new score after a game ends.
3. Sort scores in descending order.
4. Keep the five highest entries.
5. Write the result back to the file.

### 6. Complexity Analysis
- Insert at linked-list head: O(1)
- Delete at linked-list tail: O(1), because a tail pointer and previous link are maintained
- Search for an occupied coordinate: O(n)
- Self-collision detection: O(n)
- Leaderboard sorting: O(k log k), where k is the number of scores before trimming

### 7. Testing
Test the following cases:
1. Start the game using ENTER.
2. Change direction using arrow keys.
3. Eat food and confirm the score increases by 10.
4. Confirm the snake grows after eating.
5. Pause and resume using SPACE.
6. Hit a wall and confirm game over.
7. Restart using R.
8. Close and reopen the game to check saved leaderboard data.

### 8. Limitations
- The player name is currently fixed as `Player`.
- The game uses a simple grid-based visual design.
- The leaderboard stores only the top five scores.
- The project requires SFML 3 to be installed.

### 9. Future Scope
- Add a player-name entry screen.
- Add sound effects and background music.
- Add obstacles and multiple levels.
- Add a graphical leaderboard screen.
- Add more game themes and power-ups.

### 10. Conclusion
The project demonstrates how data structures can be applied to a practical game. The doubly linked list makes snake growth and movement efficient because insertion at the head and deletion at the tail both take constant time. The project also uses sorting, searching, random number generation, and file handling.

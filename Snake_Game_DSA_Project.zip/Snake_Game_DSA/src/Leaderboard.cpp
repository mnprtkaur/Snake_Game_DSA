#include "Leaderboard.h"
#include <algorithm>
#include <fstream>

Leaderboard::Leaderboard(const std::string& path) : fileName(path) {
    load();
}

void Leaderboard::load() {
    scores.clear();
    std::ifstream input(fileName);
    std::string player;
    int score = 0;

    while (input >> player >> score) {
        scores.push_back({player, score});
    }

    std::sort(scores.begin(), scores.end(),
        [](const auto& a, const auto& b) { return a.second > b.second; });
}

void Leaderboard::addScore(const std::string& player, int score) {
    scores.push_back({player, score});
    std::sort(scores.begin(), scores.end(),
        [](const auto& a, const auto& b) { return a.second > b.second; });

    if (scores.size() > 5) scores.resize(5);
    save();
}

void Leaderboard::save() const {
    std::ofstream output(fileName);
    for (const auto& entry : scores)
        output << entry.first << ' ' << entry.second << '\n';
}

int Leaderboard::findPlayerBestScore(const std::string& player) const {
    int best = 0;
    for (const auto& entry : scores) {
        if (entry.first == player && entry.second > best)
            best = entry.second;
    }
    return best;
}

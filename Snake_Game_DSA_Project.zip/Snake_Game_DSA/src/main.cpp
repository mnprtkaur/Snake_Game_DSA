#include <SFML/Graphics.hpp>
#include <algorithm>
#include <filesystem>
#include <iostream>
#include <optional>
#include <string>
#include "Snake.h"
#include "Leaderboard.h"

namespace {
    constexpr unsigned int WindowWidth = 800;
    constexpr unsigned int WindowHeight = 640;

    void drawText(sf::RenderWindow& window, const sf::Font& font,
                  const std::string& value, unsigned int size,
                  float x, float y, sf::Color color = sf::Color::White) {
        sf::Text text(font, value, size);
        text.setFillColor(color);
        text.setPosition({x, y});
        window.draw(text);
    }
}

int main() {
    std::filesystem::create_directories("scores");

    sf::RenderWindow window(
        sf::VideoMode({WindowWidth, WindowHeight}),
        "Snake Game - DSA Project"
    );
    window.setFramerateLimit(60);

    sf::Font font;
    const bool fontLoaded =
        font.openFromFile("assets/arial.ttf") ||
        font.openFromFile("C:/Windows/Fonts/arial.ttf");

    if (!fontLoaded) {
        std::cout << "Font not found. Copy arial.ttf into the assets folder.\n";
    }

    Snake snake;
    Leaderboard leaderboard;
    int score = 0;
    int bestScore = leaderboard.findPlayerBestScore("Player");
    bool started = false;
    bool paused = false;
    bool gameOver = false;

    sf::Clock movementClock;
    float moveDelay = 0.12f;
    bool enterWasDown = false;

    while (window.isOpen()) {
        while (const std::optional event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>())
                window.close();

            if (const auto* keyEvent = event->getIf<sf::Event::KeyPressed>()) {
                const auto key = keyEvent->code;

                if (key == sf::Keyboard::Key::Escape)
                    window.close();

                if (started && !paused && !gameOver)
                    snake.changeDirection(key);

                if (key == sf::Keyboard::Key::Space && started && !gameOver)
                    paused = !paused;

                if (key == sf::Keyboard::Key::R && gameOver) {
                    snake.reset();
                    score = 0;
                    moveDelay = 0.12f;
                    gameOver = false;
                    paused = false;
                    movementClock.restart();
                }
            }
        }

        const bool enterDown = sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Enter);
        if (enterDown && !enterWasDown && !started) {
            started = true;
            movementClock.restart();
        }
        enterWasDown = enterDown;

        if (started && !paused && !gameOver &&
            movementClock.getElapsedTime().asSeconds() >= moveDelay) {
            const int oldLength = snake.getLength();
            if (!snake.move()) {
                gameOver = true;
                leaderboard.addScore("Player", score);
                bestScore = std::max(bestScore, score);
            } else {
                if (snake.getLength() > oldLength) {
                    score += 10;
                    moveDelay = std::max(0.055f, moveDelay - 0.003f);
                }
            }
            movementClock.restart();
        }

        window.clear(sf::Color(12, 18, 27));

        // Header / HUD.
        sf::RectangleShape header({800.f, 60.f});
        header.setFillColor(sf::Color(23, 34, 48));
        window.draw(header);

        if (fontLoaded) {
            drawText(window, font, "SNAKE GAME", 25, 18.f, 13.f,
                     sf::Color(120, 255, 150));
            drawText(window, font, "Score: " + std::to_string(score),
                     20, 570.f, 17.f);
        }

        // Board background and subtle grid.
        sf::RectangleShape board({800.f, 560.f});
        board.setPosition({0.f, 60.f});
        board.setFillColor(sf::Color(17, 27, 38));
        window.draw(board);

        sf::RectangleShape gridLine;
        gridLine.setFillColor(sf::Color(25, 38, 50));
        for (int x = 0; x <= Snake::Columns; ++x) {
            gridLine.setSize({1.f, 560.f});
            gridLine.setPosition({static_cast<float>(x * Snake::CellSize), 60.f});
            window.draw(gridLine);
        }
        for (int y = 0; y <= Snake::Rows; ++y) {
            gridLine.setSize({800.f, 1.f});
            gridLine.setPosition({0.f, static_cast<float>(60 + y * Snake::CellSize)});
            window.draw(gridLine);
        }

        if (started) snake.draw(window);

        if (fontLoaded && !started) {
            drawText(window, font, "WELCOME TO SNAKE GAME", 34, 175.f, 220.f,
                     sf::Color(120, 255, 150));
            drawText(window, font, "Press ENTER to start", 24, 270.f, 300.f);
            drawText(window, font, "Arrow keys: Move    SPACE: Pause", 18, 215.f, 350.f);
            drawText(window, font, "Eat the red food. Avoid walls and your own body.",
                     17, 145.f, 390.f, sf::Color(190, 205, 220));
        }

        if (fontLoaded && paused && !gameOver) {
            drawText(window, font, "PAUSED", 42, 330.f, 280.f,
                     sf::Color(255, 220, 100));
            drawText(window, font, "Press SPACE to resume", 20, 285.f, 340.f);
        }

        if (fontLoaded && gameOver) {
            sf::RectangleShape overlay({800.f, 560.f});
            overlay.setPosition({0.f, 60.f});
            overlay.setFillColor(sf::Color(0, 0, 0, 175));
            window.draw(overlay);
            drawText(window, font, "GAME OVER", 42, 285.f, 235.f,
                     sf::Color(255, 100, 100));
            drawText(window, font, "Final score: " + std::to_string(score),
                     25, 315.f, 305.f);
            drawText(window, font, "Best score: " + std::to_string(bestScore),
                     21, 320.f, 345.f);
            drawText(window, font, "Press R to play again  |  ESC to exit",
                     18, 220.f, 400.f);
        }

        window.display();
    }

    return 0;
}

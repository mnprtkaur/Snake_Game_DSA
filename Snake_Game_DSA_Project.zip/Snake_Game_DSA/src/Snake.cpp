#include "Snake.h"
#include <algorithm>

Snake::Snake()
    : head(nullptr), tail(nullptr), length(0),
      randomEngine(std::random_device{}()), direction(Direction::Right) {
    reset();
}

Snake::~Snake() {
    while (tail) removeTail();
}

void Snake::addHead(Position p) {
    Node* node = new Node(p);
    node->next = head;
    if (head) head->previous = node;
    else tail = node;
    head = node;
    ++length;
}

void Snake::removeTail() {
    if (!tail) return;
    Node* oldTail = tail;
    tail = tail->previous;
    if (tail) tail->next = nullptr;
    else head = nullptr;
    delete oldTail;
    --length;
}

bool Snake::occupies(Position p) const {
    for (Node* current = head; current; current = current->next) {
        if (current->position.x == p.x && current->position.y == p.y) return true;
    }
    return false;
}

void Snake::placeFood() {
    std::uniform_int_distribution<int> xDist(0, Columns - 1);
    std::uniform_int_distribution<int> yDist(0, Rows - 1);

    do {
        food = {xDist(randomEngine), yDist(randomEngine)};
    } while (occupies(food));
}

void Snake::reset() {
    while (tail) removeTail();

    direction = Direction::Right;
    addHead({10, 14});
    addHead({9, 14});
    addHead({8, 14});

    // addHead inserts at the front; restore the intended head at x=10.
    // The sequence above results in head x=8, so rebuild in correct order.
    while (tail) removeTail();
    addHead({8, 14});
    addHead({9, 14});
    addHead({10, 14});

    placeFood();
}

void Snake::changeDirection(sf::Keyboard::Key key) {
    if (key == sf::Keyboard::Key::Up && direction != Direction::Down)
        direction = Direction::Up;
    else if (key == sf::Keyboard::Key::Down && direction != Direction::Up)
        direction = Direction::Down;
    else if (key == sf::Keyboard::Key::Left && direction != Direction::Right)
        direction = Direction::Left;
    else if (key == sf::Keyboard::Key::Right && direction != Direction::Left)
        direction = Direction::Right;
}

bool Snake::move() {
    if (!head) return false;

    Position next = head->position;
    if (direction == Direction::Up) --next.y;
    else if (direction == Direction::Down) ++next.y;
    else if (direction == Direction::Left) --next.x;
    else ++next.x;

    // Wall collision.
    if (next.x < 0 || next.x >= Columns || next.y < 0 || next.y >= Rows)
        return false;

    const bool growing = (next.x == food.x && next.y == food.y);

    // Self collision. If not growing, the old tail moves away this turn.
    for (Node* current = head; current; current = current->next) {
        if (!growing && current == tail) continue;
        if (current->position.x == next.x && current->position.y == next.y)
            return false;
    }

    addHead(next);

    if (growing) placeFood();
    else removeTail();

    return true;
}

void Snake::draw(sf::RenderWindow& window) const {
    sf::RectangleShape segment({static_cast<float>(CellSize - 2),
                                static_cast<float>(CellSize - 2)});

    for (Node* current = head; current; current = current->next) {
        segment.setPosition({
            static_cast<float>(current->position.x * CellSize + 1),
            static_cast<float>(BoardTop + current->position.y * CellSize + 1)
        });
        segment.setFillColor(current == head ? sf::Color(120, 255, 120)
                                             : sf::Color(35, 190, 95));
        window.draw(segment);
    }

    sf::CircleShape foodShape(static_cast<float>(CellSize / 2 - 2));
    foodShape.setFillColor(sf::Color(255, 90, 90));
    foodShape.setPosition({
        static_cast<float>(food.x * CellSize + 2),
        static_cast<float>(BoardTop + food.y * CellSize + 2)
    });
    window.draw(foodShape);
}

# Snake Game DSA Project - Presentation Outline

## Slide 1: Title
Snake Game Using Data Structures and Algorithms  
C++ | SFML 3 | BTech CSE

## Slide 2: Problem Statement
Create an interactive snake game and demonstrate how data structures and algorithms support its operations.

## Slide 3: Objectives
- Implement a snake using a linked list.
- Handle movement and collisions.
- Generate food randomly.
- Maintain and save scores.

## Slide 4: Technologies
C++17, SFML 3, CMake, file handling.

## Slide 5: Data Structure
Doubly linked list:
HEAD <-> node <-> node <-> TAIL  
Each node stores a coordinate and two links.

## Slide 6: Movement
Insert a new head at the next cell. Delete the tail during normal movement. Keep the tail when food is eaten.

## Slide 7: Algorithms
Movement, collision detection, random food placement, score sorting, and player search.

## Slide 8: Complexity
Head insertion O(1), tail deletion O(1), body search O(n), leaderboard sorting O(k log k).

## Slide 9: Demonstration
Show start, movement, food collection, score increase, pause, game over, restart, and saved score.

## Slide 10: Conclusion and Future Scope
The project applies linked lists, sorting, searching, randomization, and file handling in an interactive C++ application. Future improvements include named profiles, sounds, obstacles, and more levels.

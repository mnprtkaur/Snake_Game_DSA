# Snake Game - DSA Project (C++ / SFML 3)

A graphical Snake game designed as a second-year BTech CSE DSA project.

## Features
- Graphical game window and grid board
- Keyboard-controlled snake
- Snake body implemented using a manually managed doubly linked list
- Food generation at unoccupied random grid positions
- Wall and self-collision detection
- Score and increasing speed
- Pause, restart, and game-over screens
- Top-five leaderboard stored in a text file
- Leaderboard sorting using `std::sort`
- Player best-score lookup using linear search

## Requirements
- Windows 10/11
- C++17 compiler
- CMake 3.20 or newer
- SFML 3 (Graphics, Window, System)
- Arial font file copied to `assets/arial.ttf` (or available at `C:/Windows/Fonts/arial.ttf`)

## Build with CMake
Open a terminal in the project folder:

```powershell
cmake -S . -B build
cmake --build build --config Release
```

Run the executable:
- For a single-configuration MinGW build: `.\build\SnakeGame.exe`
- For Visual Studio: `.\build\Release\SnakeGame.exe`

Depending on how SFML was installed, CMake may need `CMAKE_PREFIX_PATH` set to the SFML installation folder. Example:

```powershell
cmake -S . -B build -DCMAKE_PREFIX_PATH="C:/Libraries/SFML"
```

Use the actual path where SFML 3 is installed. The compiler used to build SFML must match your compiler/toolchain.

## Controls
- ENTER: Start
- Arrow keys: Change direction
- SPACE: Pause / resume
- R: Restart after game over
- ESC: Exit

## Project structure
- `src/Snake.cpp`: linked-list representation, movement, food, collision, rendering
- `src/Leaderboard.cpp`: file handling, sorting, and player search
- `src/main.cpp`: window, input, game loop, HUD and screens
- `include/`: class declarations
- `scores/leaderboard.txt`: saved scores

## DSA explanation
The snake is stored as a doubly linked list. Each node stores a grid coordinate and links to the previous and next body segments. A new head node is inserted for every movement. If food is not eaten, the tail node is deleted; if food is eaten, the tail remains and the snake grows.

- Insert at head: O(1)
- Delete at tail: O(1)
- Check whether a coordinate is occupied: O(n)
- Self-collision check: O(n)
- Food placement: expected O(n) per attempt because occupied positions are checked
- Leaderboard sorting: O(k log k), where k is the number of stored scores (at most 5 after insertion)

## Notes
This package contains source code and documentation. It has not been compiled in your local Windows environment. Install SFML 3 and build it using the steps above. If you use a different IDE, CMake can still generate a project for it.

#pragma once
#include <string>
#include <vector>

class Leaderboard {
private:
    std::string fileName;
    std::vector<std::pair<std::string, int>> scores;

public:
    explicit Leaderboard(const std::string& path = "scores/leaderboard.txt");
    void load();
    void addScore(const std::string& player, int score);
    void save() const;
    const std::vector<std::pair<std::string, int>>& getScores() const { return scores; }
    int findPlayerBestScore(const std::string& player) const;
};

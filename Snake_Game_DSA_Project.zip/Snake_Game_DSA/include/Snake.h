#pragma once
#include <SFML/Graphics.hpp>
#include <random>

struct Position {
    int x{};
    int y{};
};

class Snake {
private:
    struct Node {
        Position position;
        Node* next;
        Node* previous;
        explicit Node(Position p) : position(p), next(nullptr), previous(nullptr) {}
    };

    Node* head;
    Node* tail;
    int length;
    Position food;
    std::mt19937 randomEngine;

    void addHead(Position p);
    void removeTail();
    bool occupies(Position p) const;
    void placeFood();

public:
    static constexpr int Columns = 40;
    static constexpr int Rows = 28;
    static constexpr int CellSize = 20;
    static constexpr int BoardTop = 60;

    Snake();
    ~Snake();
    Snake(const Snake&) = delete;
    Snake& operator=(const Snake&) = delete;

    void reset();
    bool move();
    void changeDirection(sf::Keyboard::Key key);
    void draw(sf::RenderWindow& window) const;

    int getLength() const { return length; }
    Position getFood() const { return food; }
    bool isAlive() const { return head != nullptr; }

private:
    enum class Direction { Up, Down, Left, Right };
    Direction direction;
};

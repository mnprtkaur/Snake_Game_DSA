# Snake Game DSA Project - Viva Questions

1. **Which data structure is used for the snake?**  
   A manually implemented doubly linked list.

2. **Why use a doubly linked list?**  
   It allows insertion at the head and deletion at the tail in O(1) time when both end pointers are maintained.

3. **What does each node store?**  
   The x-coordinate, y-coordinate, next pointer, and previous pointer.

4. **How does the snake move?**  
   A new head node is inserted at the next coordinate. If food is not eaten, the tail node is removed.

5. **How does the snake grow?**  
   When the next head coordinate equals the food coordinate, the tail is not deleted.

6. **What is collision detection?**  
   Checking whether the next head coordinate touches a wall or an existing body segment.

7. **What is the time complexity of insertion at the head?**  
   O(1).

8. **What is the time complexity of deleting the tail in this implementation?**  
   O(1), because each node has a previous pointer and the list maintains a tail pointer.

9. **How is food placed?**  
   Random row and column values are generated until an unoccupied cell is found.

10. **How is the leaderboard sorted?**  
    It uses `std::sort` with a comparison function that places higher scores first.

11. **What is file handling used for?**  
    To save and load leaderboard scores between program runs.

12. **What is SFML?**  
    Simple and Fast Multimedia Library, used here for graphics, window management, and keyboard input.

13. **What is the game loop?**  
    The repeated process of handling events, updating game state, drawing the frame, and displaying it.

14. **What happens when the snake hits a wall?**  
    The movement function reports failure and the game enters the game-over state.

15. **How could the project be improved?**  
    Add player names, sound, obstacles, multiple levels, and a graphical leaderboard.
